
package a3;
public class A3  {
    public static void main(String[] args) {
       new Tela().setVisible(true);
    } 
}
